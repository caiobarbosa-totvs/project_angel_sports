var INICIO_0   = 0;
var INICIO     = 4;
var INTEGRACAO = 10;
var TRATA_ERRO = 11; 
var FIM        = 16;
var COMISSAO   = 31; 