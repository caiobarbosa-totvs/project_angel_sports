var INICIO_0 = 0;
var INICIO   = 4;
var FIM      = 9;
var TRATAR_ERRO = 15;